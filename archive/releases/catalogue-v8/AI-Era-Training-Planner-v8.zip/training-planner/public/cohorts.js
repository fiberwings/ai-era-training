const layer=(id,name,budget,parent,needs,rank,extra={})=>({id,name,budget,parent,needs,rank,selected:[],pinned:[],excluded:[],internal:[],rationale:'',removedRequirements:[],addedRequirements:[],filters:{audience:true,types:[]},...extra});
export function initialCohorts(){return [
 layer('all','All users',4,null,['N1','N2','N3','N4','N5','N6'],1,{group:'Shared learning',note:'Foundation and Entry practice. N1–N6 at Base / Entry scope.'}),
 layer('practitioner','Practitioner additions',8,'all',['N7','N8','N9'],2,{group:'Shared learning',lateNeeds:['N4'],note:'Includes third-party Skill / connector vetting introduced at Practitioner.'}),
 layer('technical','Technical Expert',24,'practitioner',['N10','N11','N12','N14'],3,{group:'Expert presets',lateNeeds:['N5'],note:'Technical preset; leadership and architecture-only requirements are optional.'}),
 layer('governance','Governance Expert',24,'practitioner',['N11','N13','N14'],3,{group:'Expert presets',lateNeeds:['N5'],note:'Proposed governance scope. Review the model requirements for your actual responsibilities.'}),
 layer('leadership','Leadership / tool selection',24,'all',['N11','N13','N14'],3,{group:'Expert presets',leaders:true,lateNeeds:['N5'],note:'Decision-maker pathway; does not confer technical L3 or operational supervision authority.'}),
 layer('cdc','Incident response',4,'practitioner',['R1.1'],2,{group:'Cyber Defence Centre'}),
 layer('forensics','Agent forensics',4,'technical',['R1.1','R1.2'],3,{group:'Cyber Defence Centre'}),
 layer('idp','DLP, classification & AI risk',4,'practitioner',['N4','N7','N8','N9','N13'],3,{group:'Information Data Protection',note:'The source model has no dedicated IDP role extra. Apply these needs to DLP and classification cases.'}),
 layer('biso','Governance & assurance',4,'governance',['N13','R6.1'],3,{group:'BISO'}),
 layer('testing','Agent testing',4,'practitioner',['R3.1','R3.2'],2,{group:'Application Security'}),
 layer('redteam','Expert agent red-teaming',4,'technical',['R3.1','R3.2'],3,{group:'Application Security'}),
 layer('exposure','Exposure management',4,'practitioner',['R4.1'],2,{group:'Application Security'}),
 layer('harness','Code-analysis harnesses',4,'technical',['R4.1','R4.2'],3,{group:'Application Security'}),
 layer('architecture','Agent security architecture',4,'technical',['N12','R5.1'],3,{group:'Application Security',architect:true}),
 layer('iam','Agent identity operations',4,'practitioner',['R9.1'],2,{group:'Identity & Access Management'}),
 layer('iam-expert','Agent identity integration',4,'technical',['R9.1'],3,{group:'Identity & Access Management'}),
 layer('cio','Strategy & tool selection',4,'leadership',['N11','N13','N14'],3,{group:'CIO',leaders:true,note:'Adds learning to the leadership preset. No invented role extra.'})
];}
export function scope(data,c) {
 return data.requirements.filter(r=>{
  if(c.removedRequirements.includes(r.id)) return false;
  if(c.addedRequirements.includes(r.id)) return true;
  if(r.rank>c.rank) return false;
  if(r.level.includes('architects')&&!c.architect) return false;
  if(r.level==='Leaders'&&!c.leaders) return false;
  return c.needs.includes(r.need)||(c.lateNeeds||[]).includes(r.need)&&r.rank===c.rank;
 });
}
export function ancestors(s,c){const out=[],seen=new Set([c.id]); while(c.parent){c=s.cohorts.find(x=>x.id===c.parent);if(!c||seen.has(c.id))throw Error('Invalid cohort inheritance');seen.add(c.id);out.unshift(c);}return out;}
export function selectedIds(s,c,includeSelf=true){return [...new Set([...ancestors(s,c),...(includeSelf?[c]:[])].flatMap(x=>x.selected))];}
export function cumulativeScope(data,s,c){return [...new Map([...ancestors(s,c),c].flatMap(x=>scope(data,x)).map(r=>[r.id,r])).values()];}
