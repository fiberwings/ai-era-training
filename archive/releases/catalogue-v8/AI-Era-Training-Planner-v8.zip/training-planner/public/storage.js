import {initialCohorts,ancestors} from './cohorts.js';
export const STORE='cyber-training-planner-v1';
export function createScenario(data,name='Workshop draft'){return {schema:1,id:crypto.randomUUID(),name,status:'Draft',catalogueVersion:data.version,created:new Date().toISOString(),assumptions:'Equal weight per need. Full-course assessment evidence; course completion is not competency sign-off. Budgets exclude internal practice. Shared learning is inherited once.',overrides:{},cohorts:initialCohorts()};}
export function duplicateScenario(s){return {...structuredClone(s),id:crypto.randomUUID(),name:s.name+' — copy',status:'Draft',created:new Date().toISOString()};}
export function validateScenario(s,data){
 const fail=m=>{throw Error('Invalid scenario: '+m);};
 const strings=a=>Array.isArray(a)&&a.every(x=>typeof x==='string');
 if(!s||s.schema!==1||typeof s.name!=='string'||typeof s.id!=='string'||typeof s.catalogueVersion!=='string'||!['Draft','Reviewed','Finalised'].includes(s.status)||!Array.isArray(s.cohorts)||!s.cohorts.length)fail('unsupported format');
 if(!s.overrides||Object.values(s.overrides).some(v=>!Number.isFinite(v)||v<0)||typeof s.assumptions!=='string')fail('hours / assumptions');
 const ids=new Set();
 for(const c of s.cohorts){
  if(typeof c.id!=='string'||ids.has(c.id)||typeof c.name!=='string'||!Number.isFinite(c.budget)||c.budget<0||![0,1,2,3].includes(c.rank))fail('cohort');ids.add(c.id);
  for(const k of ['selected','pinned','excluded','needs','removedRequirements','addedRequirements'])if(!strings(c[k]))fail(k);
  if(!c.filters||!strings(c.filters.types)||typeof c.filters.audience!=='boolean'||typeof c.rationale!=='string'||!Array.isArray(c.internal))fail('cohort settings');
  if(c.pinned.some(id=>!c.selected.includes(id)))fail('pinned course must be selected');
  for(const i of c.internal)if(typeof i.id!=='string'||typeof i.title!=='string'||typeof i.owner!=='string'||typeof i.outcomes!=='string'||!['Proposed','In development','Ready'].includes(i.status)||!strings(i.requirements)||!(i.hours===null||Number.isFinite(i.hours)&&i.hours>=0))fail('internal item');
 }
 for(const c of s.cohorts)ancestors(s,c);
 const courseIds=new Set(data.courses.map(x=>x.id)),reqIds=new Set(data.requirements.map(x=>x.id)),needIds=new Set(data.needs.map(x=>x.id));
 const warnings=[];
 if(s.catalogueVersion!==data.version)warnings.push('Catalogue version differs. Review the plan against the current snapshot before finalising.');
 for(const c of s.cohorts){for(const id of new Set([...c.selected,...c.pinned,...c.excluded]))if(!courseIds.has(id))warnings.push(`${c.name}: unresolved course ${id}`);
 for(const id of [...c.addedRequirements,...c.removedRequirements,...c.internal.flatMap(i=>i.requirements)])if(!reqIds.has(id))warnings.push(`${c.name}: unresolved requirement ${id}`);
 for(const id of c.needs)if(!needIds.has(id))warnings.push(`${c.name}: unresolved need ${id}`);}
 return warnings;
}
export function serialize(s){return JSON.stringify(s,null,2);}
export function deserialize(text,data){const s=JSON.parse(text);return {scenario:s,warnings:validateScenario(s,data)};}
export function csv(rows){const cell=v=>{let s=String(v??'');if(/^[=+@-]/.test(s))s="'"+s;return '"'+s.replaceAll('"','""')+'"';};return '\uFEFF'+rows.map(r=>r.map(cell).join(',')).join('\r\n');}
