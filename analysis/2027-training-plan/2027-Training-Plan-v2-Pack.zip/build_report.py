"""Build the self-contained annual report, exports and versioned delivery pack."""
import base64,csv,hashlib,html,json,zipfile
from pathlib import Path
from verify_analysis import verify
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
verify()
R=json.loads((HERE/'results-v2.json').read_text());D=R['design'];S=R['scenarios'];rows=S[0]['rows'];by={x['id']:x for x in rows}
e=lambda s:html.escape(str(s),quote=True)
pct=lambda n:f'{n*100:.1f}%'
def hrs(n):
    m=round(n*60);return f'{m//60}h {m%60:02d}m' if m%60 else f'{m//60}h'
def table(headers,records):return '<div class="tablewrap"><table><thead><tr>'+''.join('<th scope="col">'+e(x)+'</th>' for x in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+x+'</td>' for x in row)+'</tr>' for row in records)+'</tbody></table></div>'
def course_list(row):return '<br>'.join(f'<a href="{e(c["url"])}" target="_blank" rel="noopener">{e(c["title"])}</a><small>{e(c["id"])} · {hrs(c["hours"])}</small>' for c in row['details']) or 'Internal practice only'
def write_csv(name,head,body):
    with (HERE/name).open('w',encoding='utf-8-sig',newline='') as f:
        csv.writer(f).writerows([["'"+v if isinstance(v,str) and v.startswith(('=','+','-','@')) else v for v in row] for row in [head]+body])
files=[]
def export(name,head,body):write_csv(name,head,body);files.append(name)
export('time-and-coverage-v2.csv',['Scenario','Cohort','Agentic level','Role specialisms','Own outcomes','Course budget h','Own course h','Own internal h','Cumulative course h','Cumulative internal h','Cumulative learner h','Own-layer coverage %','Cumulative coverage %','Own critical zeros','Cumulative critical zeros'],[[s['name'],x['name'],x['profile']['level'],'; '.join(x['profile']['specialisms']),len(x['scopeIds']),x['budget'],x['courseHours']['hours'],x['ownInternalHours'],x['cumulativeCourseHours']['hours'],x['internalHours'],x['totalHours'],100*x['coverage'],100*x['cumulativeCoverage'],x['critical'],x['cumulativeCritical']] for s in S for x in s['rows']])
export('course-selections-v2.csv',['Scenario','Cohort','ID','Course','Provider','Source hours text','Planning hours','Duration basis','Cost metadata at review','URL','Source sheet','Source row','Selection rationale'],[[s['name'],x['name'],c['id'],c['title'],c['provider'],c['duration'],c['hours'],c['durationBasis'],c['cost'],c['url'],c['source']['sheet'],c['source']['row'],x['rationale']] for s in S for x in s['rows'] for c in x['details']])
export('need-coverage-v2.csv',['Scenario','Cohort','Need','Title','Outcomes','Coverage %','Band','Critical zeros','Score-3 outcomes'],[[s['name'],x['name'],n['id'],n['title'],n['count'],100*n['coverage'],n['band'],n['critical'],n['full']] for s in S for x in s['rows'] for n in x['needs']])
export('requirement-evidence-and-gaps-v2.csv',['Scenario','Cohort','Requirement','Title','Critical','Selected score','Assessment status','Catalogue maximum','Gap','Witness IDs','Evidence','Evidence source rows','Proposed internal IDs'],[[s['name'],x['name'],r['id'],r['title'],r['core'],r['score'],r['status'],r['ceiling'],r['gap'],'; '.join(c['id'] for c in r['evidence']),' | '.join(c['id']+': '+c['evidence'] for c in r['evidence']),' | '.join(c['id']+': '+c['source']['sheet']+' row '+str(c['source']['row']) for c in r['evidence']),'; '.join(i['id'] for i in r['internal'])] for s in S for x in s['rows'] for r in x['requirementDetails']])
export('internal-commitments-v2.csv',['Scenario','Cohort','ID','Title','Learner hours','Owner','Requirements','Evidence','Status'],[[s['name'],x['name'],i['id'],i['title'],i['hours'],i['owner'],'; '.join(i['requirements']),i['outcomes'],i['status']] for s in S for x in s['rows'] for i in x['internalItems']])
export('in-house-build-briefs-v2.csv',['Route','ID','Title','Cohorts','Hours','Requirements','Owner','Why','Agenda','Evidence','Prerequisites','Build low h','Build high h','Wave','Status'],[[route,m['code'],m['title'],'; '.join(m['cohorts']),m['hours'],'; '.join(m['requirements']),m['owner'],m['why'],m['agenda'],m['evidence'],m['prerequisites'],*m['buildHoursEstimate'],m['wave'],m['status']] for route,ms in [('Recommended',D['modules']),('Coached additions',D['adaptations'])] for m in ms])
export('capability-crosswalk-v2.csv',['ID','Need','Title','Component','Shared agentic level','Role specialisms','Critical','Historical source level'],[[r['id'],r['need'],r['title'],r['component'],r['agenticLevel'] if r['agenticLevel'] is not None else '', '; '.join(r['specialisms']),r['core'],r['sourceLevel']] for r in R['model']['crosswalk']])
shared=table(['Learning layer','Assigned external learning','Course / internal time','Cumulative learner time','Layer evidence coverage'],[[f'<strong>{e(x["name"])}</strong><small>{len(x["scopeIds"])} additional outcomes</small>',course_list(x),hrs(x['courseHours']['hours'])+' / '+hrs(x['ownInternalHours']),hrs(x['totalHours']),pct(x['coverage'])+f'<small>{x["critical"]} critical outcomes at zero</small>'] for x in rows[:4]])
roles=table(['Role pathway','Parent level','Additional external learning','Role course / internal time','Total learner time','Role evidence coverage'],[[f'<strong>{e(x["name"])}</strong><small>{e(x["audience"])}</small>','L'+str(x['profile']['level']),course_list(x),hrs(x['courseHours']['hours'])+' / '+hrs(x['ownInternalHours']),hrs(x['totalHours']),pct(x['coverage'])] for x in rows[4:]])
selected={c['id']:c for x in rows for c in x['details']};dla=[c for c in selected.values() if 'DeepLearning' in c['provider']]
fit={'TR-193':'Accessible L1 prompting and iteration; the bank work case supplies context and verification.','TR-100':'Task traces and evaluation for agent supervisors; code readiness required.','TR-191':'Reusable Skills and tool use; library ownership, review and retirement need bank practice.','TR-198':'A structured multi-agent programme for code-ready L3 builders; security roles remain separately assigned.','TR-229':'Routing and cost/latency decisions; validate o1-era notebooks before delivery.','TR-238':'Known-answer evaluation and iterative improvement; human calibration remains internal.','TR-179':'Repository context and review-agent practice for code-analysis engineers; vulnerability validation remains internal.','TR-094':'MCP client/server integration for infrastructure engineers; production access controls need bank implementation.'}
dlatable=table(['Course','Planning time','Reason for inclusion'],[[f'<a href="{e(c["url"])}" target="_blank" rel="noopener">{e(c["title"])}</a><small>{c["id"]}</small>',hrs(c['hours']),e(fit[c['id']])] for c in dla])
compare=table(['Scenario','Use','L1 layer coverage','L2 layer coverage','L3 layer coverage','L3 cumulative learner time'],[[e(s['name']),e(['Recommended curriculum for audience-matched delivery.','Replace the L1 course for Python/Git-ready learners with approved coding access.','Design-dependent alternative for no-code learners; internal teaching must be piloted and assessed.','Diagnostic score comparison; selections are not endorsed for delivery.'][i]),*[pct(next(x for x in s['rows'] if x['id']==cid)['coverage']) for cid in ['entry','practitioner','technical']],hrs(next(x for x in s['rows'] if x['id']=='technical')['totalHours'])] for i,s in enumerate(S)])
briefs=''
for m in D['modules']+D['adaptations']:
 briefs+=f'<details><summary>{e(m["code"])} · {e(m["title"])} · {hrs(m["hours"])}</summary><p><strong>Audience:</strong> {e(", ".join(by[i]["name"] for i in m["cohorts"]))}</p><p><strong>Owner / timing:</strong> {e(m["owner"])} · {e(m["wave"])}</p><p>{e(m["why"])}</p><p><strong>Exercise:</strong> {e(m["agenda"])}</p><p><strong>Evidence to retain:</strong> {e(m["evidence"])}</p><p><strong>Prerequisites:</strong> {e(m["prerequisites"])}</p><small>Targets: {e(", ".join(m["requirements"]))}. One-time development estimate: {m["buildHoursEstimate"][0]}–{m["buildHoursEstimate"][1]}h. Proposed; no scored credit.</small></details>'
cases=table(['Function','Candidate case','Evidence needed'],[[e(x[k]) for k in ['function','candidate','evidence']] for x in D['cases']])
modeltable=table(['Model component','Assignment rule'],[['Foundation · 29 outcomes','Common knowledge for everyone across N1–N5, excluding responsibility-specific N4.7 and N5.7.'],['L1 · 8 additional outcomes','AI-assisted work: N6.'],['L2 · 16 additional outcomes','Agent supervision: N7–N9 and N4.7.'],['L3 · 11 additional outcomes','Agent building and evaluation: N10–N11, excluding infrastructure N10.3/N10.6/N10.7. Coding is not the level definition.'],['Role responsibilities','Add the relevant security, risk, leadership, transformation, identity and other specialist outcomes independently of agentic level. Overlapping outcomes count once.'],['Approved products','Add product learning only for actual approved access. It does not redefine the capability score or confer workplace permission.']])
rolemap=table(['Role family','Responsibility mapping'],[[e(str(x['id'])+' · '+x['name']),e(x['needs'])] for x in R['model']['roles']])
capacity=[sum(m['buildHoursEstimate'][i] for m in D['modules']) for i in [0,1]]
files += [s['id']+'.json' for s in S]+['plan-config-v2.json','in-house-design-v2.json','results-v2.json','verification-v2.json']
embedded={f:base64.b64encode((HERE/f).read_bytes()).decode() for f in files}
embedded['Agentic-Era_Workforce_Capability_Model.md']=base64.b64encode((ROOT/'Agentic-Era_Workforce_Capability_Model.md').read_bytes()).decode()
links=''.join(f'<a href="#downloads" data-download="{e(f)}">{e(f)}</a>' for f in [S[0]['id']+'.json','time-and-coverage-v2.csv','course-selections-v2.csv','requirement-evidence-and-gaps-v2.csv','in-house-build-briefs-v2.csv','capability-crosswalk-v2.csv'])
replacements={'SHARED':shared,'ROLES':roles,'DLA':dlatable,'COMPARE':compare,'BRIEFS':briefs,'CASES':cases,'MODEL':modeltable,'ROLEMAP':rolemap,'LINKS':links,'BUILD':f'{capacity[0]}–{capacity[1]}','COURSES':str(len(selected)),'DLA_COUNT':str(len(dla)),'CATALOGUE':R['catalogueVersion'],'HASH':R['sourceSha256'],'STYLE':(HERE/'report_styles.css').read_text(),'UI':(HERE/'report_ui.js').read_text(),'DATA':json.dumps(R,ensure_ascii=False).replace('<','\\u003c'),'FILES':json.dumps(embedded),'EXPLORERFALLBACK':shared}
report=(HERE/'report_template.html').read_text()
for key,value in replacements.items():report=report.replace('{{'+key+'}}',value)
assert '{{' not in report
for name in ['2027-Training-Plan-v2.html','2027-Training-Plan.html']:(HERE/name).write_text(report)
pack=HERE/'2027-Training-Plan-v2-Pack.zip'
with zipfile.ZipFile(pack,'w',zipfile.ZIP_DEFLATED) as z:
 for f in files+['2027-Training-Plan-v2.html','build_plan.mjs','build_report.py','verify_analysis.py','report_template.html','report_styles.css','report_ui.js','Read-me-v2.txt']:
  z.write(HERE/f,f)
 z.write(ROOT/'Agentic-Era_Workforce_Capability_Model.md','Agentic-Era_Workforce_Capability_Model.md')
 z.write(HERE/'archive/v1-before-model-v2-20261018/archive-manifest.json','previous-version-archive-manifest.json')
(HERE/'2027-Training-Plan-Pack.zip').write_bytes(pack.read_bytes())
print(f'Built report v2: {len(report):,} characters, {len(files)} embedded exports, {len(rows)} recommended profiles; pack {pack.stat().st_size:,} bytes')
